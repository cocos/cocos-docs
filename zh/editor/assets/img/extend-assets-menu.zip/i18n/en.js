"use strict";

module.exports = {
  title: "Extend Assets Menu Demo",

  menu: {
    createAsset: "Create asset in my way",
    dropMeToAssets: "Drop me to assets panel，see console.log",
    assetCommand: "My defined asset context menu command",
    runCommand: "Click run this command",
  },

  method: {
    dropAsset:
      "The Assets panel has successfully executed your custom drag and drop behavior and fed back the data:",
    createAsset:
      "The Assets panel right click menu has executed the default custom create resource instruction and feedback the data:",
    assetCommand:
      "The Assets panel right click menu has executed the default custom resource instruction, and feedback the data:",
  },
};
