'use strict';

exports.methods = {
  open() {
    Editor.Panel.open('extend-assets-demo');
  },
};
