module.exports = {
    template: `
    <ui-prop>
        <ui-label slot="label" value="Main Color"></ui-label>
        <ui-color id="color" slot="content" tabindex="0"></ui-color>
    </ui-prop>
    `,
    $: {
        color: '#color',
    },
    methods: {
        /**
         * 
         * @param {{r:number,g:number,b:number,a:number}} color 
         * @returns 
         */
        colorToUIColor(color) {
            return [color.r, color.g, color.b, color.a];
        },
        /**
         * 
         * @param {number[]} UIColor 
         * @returns 
         */
        UIColorToColor(UIColor) {
            return { r: UIColor[0], g: UIColor[1], b: UIColor[2], a: UIColor[3] };
        }
    },
    update(material, assetList, metaList) {
        this.material = material;
        // 找到材质中的颜色
        this.mainColor = this.material.data[0].passes[0].props.find(prop => { return prop.name === 'mainColor'; });
        // 同步面板与材质的颜色
        this.$.color.value = this.colorToUIColor(this.mainColor.value);
    },
    ready() {
        if (this.$.color) {
            // 监听颜色变换
            this.$.color.addEventListener('confirm', (event) => {
                // 设置材质的颜色
                this.mainColor.value = this.UIColorToColor(event.target.value);
                // 发送修改事件，通知面板材质被修改了
                this.dispatch('change');
            })
        }
    },
}
